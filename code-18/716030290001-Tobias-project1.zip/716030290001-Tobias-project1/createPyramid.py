import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from skimage import data
import pickle
from skimage.transform import pyramid_gaussian

def generatePyramidFromPath(path):
    image = np.array(Image.open(path).resize((512,512)).convert("RGB"))
    #image = data.astronaut()
    print(image.shape)
    rows, cols, dim = image.shape
    pyramid = tuple(pyramid_gaussian(image, downscale=2, multichannel=True))

    composite_image = np.zeros((rows, cols + cols // 2, 3), dtype=np.double)

    composite_image[:rows, :cols, :] = pyramid[0]
    images = []
    images.append(image)

    i_row = 0
    for p in pyramid[1:]:
        n_rows, n_cols = p.shape[:2]
        if n_rows < 96:
            break
        print("image size: {}".format(p.shape[:2]))
        images.append(p)
        composite_image[i_row:i_row + n_rows, cols:cols + n_cols] = p
        i_row += n_rows

    #fig, ax = plt.subplots()
    #ax.imshow(images[2])
    #plt.show()
    return images

def getCroppedImage(img, x, y):
    return [i[x:x+96] for i in img[y:y+96]]

#returns [ [cropped img,..],... ]
def createAndCropPyramid(pyramid):
    results = []
    for img in pyramid:
        print(img.shape)
        X = []
        for y in range(int((img.shape[0]-96)/10)):
            for x in range(int((img.shape[1]-96)/10)):
                X.append(getCroppedImage(img, x*10, y*10))
        print("appended img")
        results.append(np.array(X))
    return results

def saveToFile(filePath, data):
    with open(filePath, 'wb') as fp:
        pickle.dump(data, fp)

path_to_image = "example.jpg"
pyramid = generatePyramidFromPath(path_to_image)
saveToFile("pyramidImages", pyramid)
data = createAndCropPyramid(pyramid)
saveToFile("pyramid", data)