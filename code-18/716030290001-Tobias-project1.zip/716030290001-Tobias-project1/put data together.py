import numpy as np
import pickle

tdc = "trainingDataComplete-folder-"
tdh = "trainingDataHog-folder-"

def load(path):
    folder_1_to_4 = []
    folder_5_to_8 = []
    folder_9_to_10 = []

    for i in range(10):
        with open (path+"{}".format(i+1), 'rb') as fp:
            if i < 4:
                folder_1_to_4 += pickle.load(fp)
                print("finished 1-4")
            elif i > 3 and i < 8:
                folder_5_to_8 += pickle.load(fp)
                print("finished 5-8")
            else:
                folder_9_to_10 += pickle.load(fp)
                print("finished 9-10")
    return folder_1_to_4, folder_5_to_8, folder_9_to_10


def saveToFile():
    #folder_1_to_4, folder_5_to_8, folder_9_to_10 = load(tdc)

    #with open("trainingData/"+tdc+"1-to-4", 'wb') as fp:
    #    pickle.dump(folder_1_to_4, fp)
    #with open("trainingData/"+tdc+"5-to-8", 'wb') as fp:
    #    pickle.dump(folder_5_to_8, fp)
    #with open("trainingData/"+tdc+"9-to-10", 'wb') as fp:
    #    pickle.dump(folder_9_to_10, fp)
    
    folder_1_to_4, folder_4_to_8, folder_9_to_10 = load(tdh)

    with open("trainingData/"+tdh+"1-to-4", 'wb') as fp:
        pickle.dump(folder_1_to_4, fp)
    with open("trainingData/"+tdh+"4-to-8", 'wb') as fp:
        pickle.dump(folder_4_to_8, fp)
    with open("trainingData/"+tdh+"9-to-10", 'wb') as fp:
        pickle.dump(folder_9_to_10, fp)

saveToFile()