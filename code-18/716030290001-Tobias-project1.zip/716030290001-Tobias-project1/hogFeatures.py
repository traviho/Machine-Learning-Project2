import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from PIL import Image
import os
import pickle

pictureSize = (96,96)
blockSize = (2,2)	#size of blocks
cellSize = (16,16)	#size of cells in which img gets divided
binCount = 9		#bins of histogramm
blockOverlap = 1	#block overlapping
labels = ["1-to-4", "5-to-8", "9-to-10"]
td_path = "trainingData/trainingDataComplete-folder-"
output_path = "trainingDataHog-folder-"
currentLabel = 0
testingData = []

rgb2gray = lambda rgb : np.dot(rgb[...,:3], [0.2989, 0.5870, 0.1140])
vector2DLength = lambda x,y: np.sqrt(x*x + y*y)

# creates a gradient vector map
def createGradVectorMap(ImgArray2d):		#returns a (angle, length(norm)) matrix
	picture = rgb2gray(ImgArray2d)						#grayscale

	#generate map of (angle, length) vectors
	getRightPixel = lambda x,y: picture[y][x+1] if x+1 < pictureSize[1] else picture[y][x]
	getLeftPixel = lambda x,y: picture[y][x-1] if x-1 >= 0 else picture[y][x]
	getTopPixel = lambda x,y: picture[y-1][x] if x-1 >= 0 else picture[y][x]
	getBottomPixel = lambda x,y: picture[y+1][x] if y+1 < pictureSize[0] else picture[y][x]

	vectorImage = []
	for y in range(pictureSize[1]):
		vectorImage.append([])
		for x in range(pictureSize[0]):
			xDot = getLeftPixel(x,y)-getRightPixel(x,y)+0.000000000000000000000001
			yDot = getTopPixel(x,y)-getBottomPixel(x,y)+0.000000000000000000000001
			angle = 2*np.pi if yDot < 0 else 0				#y is negative
			angle = np.pi if xDot < 0 else angle			#x is negative
			if xDot == 0 and yDot == 0:
				angle = 0
			elif xDot == 0:
				angle = np.pi*3/2 if yDot < 0 else np.pi/2
			elif yDot == 0:
				angle = np.pi if xDot < 0 else 0 
			else:
				angle += np.arctan(yDot/xDot)
			
			length = vector2DLength(xDot/255, yDot/255)
			vectorImage[y].append((angle, length))
	return vectorImage

#
def getCell(x,y, gVectMap):	#returns a Box as an arrray
	hist = []
	for i in range(cellSize[0]):
		for j in range(cellSize[1]):
			hist.append(gVectMap[i+y][j+x])
	return hist

def generateHistogramm(data, bins):		#x in data = (angle [0,2*pi), length(norm))
	rad = lambda a: a*180/np.pi
	normAngle = lambda a: rad(a)-180 if rad(a)>180 else rad(a)		#angle(a) if a -np.pi<0 else angle(a)-180 #[0,180]
	histoarray = [0]*bins

	for featureVector in data:
		angle = normAngle(featureVector[0])-10		#[-10,170]
		vectorLength = featureVector[1]*2
		if angle % bins == 0:
			histoarray[angle] += vectorLength
		else:
			tmp = angle*bins/180
			pos = int(np.floor(tmp))
			distribution = tmp-pos
			histoarray[pos] += (1-distribution)*vectorLength
			histoarray[pos+1 if pos+1 < bins else 0] += distribution*vectorLength
	return histoarray

def createHistogrammList(gradVectorMap):
	width = int(pictureSize[0]/cellSize[0])
	height = int(pictureSize[1]/cellSize[1])

	hist4cell = lambda x,y : generateHistogramm(getCell(x, y, gradVectorMap), binCount)
	histogramList = [[hist4cell(xBox, yBox) for xBox in range(width)] for yBox in range(height)]
	return histogramList

#returns a [5*5*4*9]->1d array
def createHOG(gradVectorMap):
	width = int(pictureSize[0]/cellSize[0])
	height = int(pictureSize[1]/cellSize[1])

	histogramList = createHistogrammList(gradVectorMap)
	
	#generate the Blocks
	addCells = lambda x,y: np.array([histogramList[y][x], histogramList[y+1][x], histogramList[y][x+1], histogramList[y+1][x+1]])
	blockList =	[np.array([addCells(x,y) for x in range(width-1)]) for y in range(height-1)]
	blockList = np.array(blockList)
	return np.ravel(blockList)


#this method calculates the 900 feature vectors of the immages and puts them with the labels in a file
def trainingDataToHog(trainingData):
	print("creating labeled hog list from trainingdata")
	hogData = [{"x":createHOG(createGradVectorMap(labeledData["x"])), "y":labeledData["y"]} for labeledData in trainingData]
	print("finished")
	saveTrainingDataToFolder(hogData)

def saveTrainingDataToFolder(hogData):
	with open('{}{}'.format(output_path,currentLabel), 'wb') as fp:
		pickle.dump(hogData, fp)

def hogFromFolder():
	for i in range(3):
		currentLabel = i
		trainingData = []
		with open ('{}{}'.format(td_path, labels[i]), 'rb') as fp:	#'trainingData
			trainingData = pickle.load(fp)

		trainingDataToHog(trainingData)


def getHogFromPyramid(path):
	pyramid = None	#[ (img, [(img, x, y), (img, x, y)]), ... ]
	with open (path, 'rb') as fp:
		pyramid = pickle.load(fp)
	outp =[]
	for imgs in range(len(pyramid)):
		tmp = []
		for cropedImg in range(len(pyramid[imgs])):
			tmp.append(createHOG(createGradVectorMap(pyramid[imgs][cropedImg])))
			
			if cropedImg%100 == 0:
				print("{} hogs created".format(cropedImg))
		outp.append(tmp)
	with open('pyramid-hog', 'wb') as fp:
		pickle.dump(outp, fp)

#hogFromFolder()
getHogFromPyramid("pyramid")






