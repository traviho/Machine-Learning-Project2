import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from PIL import Image
import os
import pickle

pictureSize = (96,96)
trainingData = []
testingData = []
folderName = "trainingDataComplete"	#trainingData just has a "small" sample of one Folder
path_to_FDDB = "../FDDB-folds"

#<rBig, rSmall, angle, xCenter, yCenter> -> <width, height, x, y>
#width = (2*rSmall)(4/3); hight = (2*rBig)(4/3); x = xCenter-rSmall; y = yCenter-rBig
def changeBoundingBoxFormat(elypsisData):
	data = elypsisData.split(" ")
	rBig = float(data[0])
	rSmall = float(data[1])
	xCenter = float(data[3])
	yCenter = float(data[4])
	return {"width" : int(2*rSmall*(4/3)), "height" : int(2*rBig*(4/3)), "x" : int(xCenter-(4/3)*rSmall), "y":int(yCenter-(4/3)*rBig)}

#reads textfile and creates array with elements {filename, headCount, headPosition [pos0, pos1, ...] }
#posX = [width, height, x, y]
def readDataFromTxtFile(filename):
	folderCompleteDesc = open(filename)
	lines = []
	tmp = {}
	headCount = False			#checks if the current number is the headcount
	for line in folderCompleteDesc:
		data = line.rstrip()
		if '/' in data:
			if len(tmp) > 0:
				lines.append(tmp)
			tmp = {}
			picturePath = "../{}.jpg".format(data)
			tmp["imgPath"] = picturePath		#tmp.append(picturePath)
			headCount = True
		elif headCount:			#if it is the headCount
			tmp["headCount"]=data
			headCount = False
		else:					#if not, make a list for them
			if not "headPosition" in tmp:
				tmp["headPosition"] = []
			tmp["headPosition"].append(changeBoundingBoxFormat(data))
			
	folderCompleteDesc.close()
	return lines

#read every txt and returns a array of the folders X images 
#pictureData[folder][image] = {filename, headCount, headPosition [pos0, pos1, ...] }
def getPictureDataFromFolders(fromFolder, toFolder):
	pictureData = []
	for i in range(fromFolder, toFolder+1):
		fileName = "0" + str(i) if i<10 else "10"
		txfData = readDataFromTxtFile(path_to_FDDB + "/FDDB-fold-{}-ellipseList.txt".format(fileName))
		pictureData.append(txfData)
	return pictureData

#creates positive and negative labeled data [img (array), label] and appends it to training Data
def createSampleFromImage(image, boundingBox, traindata):
	imageArray = np.array(image)
	for i in range(3):
		for j in range(3):
			head = []
			for y in range(boundingBox["height"]):
				head.append([])
				for x in range(boundingBox["width"]):
					yPos = int(y + boundingBox["y"]-boundingBox["height"]/3 + boundingBox["height"]*j/3)
					yPos = 0 if yPos < 0 else yPos if yPos < len(imageArray) else len(imageArray)-1
					xPos = int(x + boundingBox["x"] -boundingBox["width"]/3 + boundingBox["width"]*i/3)
					xPos = 0 if xPos < 0 else xPos if xPos < len(imageArray[yPos]) else len(imageArray[yPos])-1
					head[y].append(imageArray[yPos][xPos])
			
			try:
				img = Image.fromarray(np.array(head), 'RGB')
				img = img.resize(pictureSize)
				d = {"x": np.array(img), "y": (1 if i==2 and j == 2 else -1) }
				if not i == 2 and j == 2 and not traindata:
					testingData.append(d)
				else:
					trainingData.append(d)
			except:
				pass
			
def createTrainingDataFomFolders(startF,endF):
	testSmallSample = getPictureDataFromFolders(startF, endF)
	fo, fi= (0,0)
	for folder in testSmallSample:
		fo += 1
		for files in folder:
			fi += 1
			inputImage = Image.open(files["imgPath"])
			for headBB in files["headPosition"]:
				createSampleFromImage(inputImage, headBB, True)
			if fi % 20 == 1:
				print("labels up to folder: {}\tfile: {}".format(fo,fi))
	saveTrainingDataToFolder("{}-to-{}".format(startF, endF))

def saveTrainingDataToFolder(folderNameExtension):
	with open("trainingData/{}-folder-{}".format(folderName,folderNameExtension), 'wb') as fp:
		pickle.dump(trainingData, fp)
	


createTrainingDataFomFolders(1,4)