import numpy as np
#import pylab as pl
from sklearn import svm, datasets
import matplotlib.pyplot as plt
#import matplotlib.image as mpimg
from PIL import Image
import os
import pickle
from random import seed
from random import randrange
import functools

path2model = "trained-models"
trainingDataFile = 'trainingData/trainingDataHog-folder-'#'trainingDataHOG'
files = ["1-to-4", "5-to-8", "9-to-10"]
sigmoid = lambda x: 1/(1+np.exp(-x))

"""
    this method gets the training data from the trainingData-folder
    @returns X, Y, X_val, Y_val     X,Y = folder 1-8 (4-8 only pos. samples),
                                    X_val, Y_val = folder 4-10 (4-8 only neg. samples)
"""
def getTrainingData():
    X = []
    Y = []
    X_val = []
    Y_val = []
    for i in range(3):
        tmp = []
        with open (trainingDataFile+files[i], 'rb') as fp:
            tmp = pickle.load(fp)
        if i == 0:
            X += list(map(lambda u: u["x"], tmp))
            Y += list(map(lambda u: u["y"], tmp))
        elif i == 1:
            X += [i["x"] for i in tmp if i["y"] == 1]
            Y += [i["y"] for i in tmp if i["y"] == 1]
            X_val += [i["x"] for i in tmp if i["y"] == -1]
            Y_val += [i["y"] for i in tmp if i["y"] == -1]
        else:
            X_val += list(map(lambda u: u["x"], tmp))
            Y_val += list(map(lambda u: u["y"], tmp))

        print("loaded-data-folder: {}".format(i+1))
    
    print("----------------| finished loading data -> let the fun begin |----------------")
    return np.array(X), np.array(Y), np.array(X_val), np.array(Y_val)

"""
    This method chooses the right model and trains it
    @X,Y = standard dataset
    @model = modelName 
    @kernel = kernelname {linear | rbf | poly| sigmoid}
        !!!!!Kernel WORKS ONLY FOR SVM!!!!
"""
def trainModel(X,Y, model, kernel, langevinDynamics):
    C = 1.0  # SVM regularization parameter
    mod = None
    if model == "LogReg":
        mod = logistic_regression(X,Y, steps = 1000000, learning_rate = 0.000001, langevinDynamics=False)
    elif model == "LDA":
        mod = linearDiscriminantAnalyisis(X, Y, langevinDynamics)
    else:
        if kernel == 'linear':
            mod = svm.LinearSVC(C=C).fit(X,Y)
        elif kernel == 'rbf':
            mod = svm.SVC(kernel='rbf', gamma=0.7, C=C,).fit(X, Y)
        elif kernel == 'poly':
            mod = svm.SVC(kernel='poly', degree=3, C=C).fit(X, Y)
        else:
            mod = svm.SVC(kernel='sigmoid', C=C).fit(X, Y)
    return mod

"""
model = - SVM [linear | rbf | poly| sigmoid]
        - LogReg
        - LDA [lagevinDynamics]
    @X,Y -> np.arrays X = 900-dim vector, Y constists of elem. from {-1,1}
"""
def loadModel(X, Y, modelName, kernel = "", newDataSet=False, langevinDynamics=False):
    mod = None
    k = "{}-".format(kernel) if not kernel == "" else "" 
    if loadModelFromFile(modelName, kernel)[0] or newDataSet:
        k = "LangevinDynamics-" if modelName == "LDA" and langevinDynamics == True else k 
        print("started training {}{}".format(k,modelName))
        mod = trainModel(X,Y, modelName, kernel, langevinDynamics)
        saveModelTofile(modelName, kernel, mod)
        print("created {}{}".format(k,modelName))
    else:
        mod = loadModelFromFile(modelName, kernel)[1]
        print("loaded {}{}".format(k,modelName))
    return mod

#----------------------------------
"""
    is used by by logisticRegression
    returns the actual accuracy
"""
def log_likelihood(X, Y, B):
    scores = np.dot(X, B)
    ll = np.sum( Y*scores - np.log(1 + np.exp(scores)) )
    return ll

"""
    This method is the logistic regression
"""
#TODO to bad results
def logistic_regression(X, Y, steps, learning_rate, langevinDynamics = False):
    seed(1234)
    B = np.zeros(X.shape[1])
    #make input to the right shape
    Y_ = [x if x > 0 else 0 for x in Y] #Y_ = Y from [0,1]
    
    for step in range(steps):
        # Update B with SGD Stochastic gradient desced
        random_index = randrange(len(Y_))               #get random training data
        Y_hat = sigmoid(np.dot(X[random_index], B))     #get y_hat by generating an output from the random Data
        
        langevin = 0 if not langevinDynamics else np.random.normal()
        tmp = learning_rate*(Y_[random_index]-Y_hat)*Y_hat*(1-Y_hat)  #B = B +learn_rate* (y-y^)*y^*(1-y^)*X[random_index]]
        B = np.array(list(map(lambda a,b: a+(b*tmp), B, X[random_index]))) - langevin #B = B + X[random_index] * a [- langevin] optional
        

        if step % 100000 == 0:
            print("ll: {}\tout: {}\texpected: {}".format(log_likelihood(X, Y_, B), Y_hat, Y_[random_index]))
    return B

#TODO not working properly
"""
    This is a method for the linearDiscriminantAnalysis
"""
def linearDiscriminantAnalyisis(X ,Y):
    # sort positive and negative samples
    class1_data = list(filter(lambda i: Y[i]==1,range(len(Y))))
    class2_data = [i for i in range(len(Y)) if not i in class1_data]

    class1_data = [X[i] for i in class1_data]
    class2_data = [X[i] for i in class2_data if i%7==0]

    class1_len = len(class1_data)
    class2_len = len(class2_data)

    print("anz class1: {}\tclass2: {}".format(class1_len, class2_len))

    add_arrays = lambda a,b: list(map(lambda c,d: c+d, a,b))
    #calculate means (mü)
    class_mean = lambda data: functools.reduce(add_arrays, data) 
    class1_mean = class_mean(class1_data)       #u1
    class2_mean = class_mean(class2_data)       #u2
    mean = list(map(lambda a,b: a+b, [x/class1_len for x in class1_mean], [y/class2_len for y in class2_mean]))
    print("Class1.mean: {}\tClass2.mean: {}\tmean: {}".format(len(class1_mean), len(class2_mean), len(mean)))

    #mean corrected data (classI_data - mean)
    sub_mean = lambda data,mean: data-mean
    mcd = lambda data: list(map(lambda x: list(map(sub_mean, x, mean)), data)) 

    class1_mcd = mcd(class1_data)
    class2_mcd = mcd(class2_data)
    print("mean corrected data|\tclass1: {}\tclass2: {}\tdim: {}".format(len(class1_mcd), len(class2_mcd), len(class1_mcd[0])))
    
    # transpose the matrixes
    class1_mcd_T = np.transpose(class1_mcd)
    class2_mcd_T = np.transpose(class2_mcd)

    #covariance matrixes = mcd^T*mcd/len(class)
    coma1 = np.dot(class1_mcd_T, class1_mcd)/class1_len
    coma2 = np.dot(class2_mcd_T, class2_mcd)/class2_len

    print("dim covar. matrix1: {}\tmatrix2: {}".format(coma1.shape, coma2.shape))
    
    #C = (coma1 * class1.len + coma2 * class2.len)/len(Y)
    C = (coma1*class1_len + coma2*class2_len)/len(Y)
    C = np.matrix(C)
    print(C.shape)
    C_inv = np.linalg.pinv(C)     #inverse of C
    print(C_inv.shape)
    #Class propability
    p_class = [class1_len/len(Y), class2_len/len(Y)]

    fisherModel(coma1, coma2, class1_mean, class2_mean) #get Data from the fisher model

    return (np.array([class1_mean, class2_mean]), C_inv, p_class)

"""
    This method calculates the inter, intra class difference
    as well as the fisher model by deviding those two
"""
def fisherModel(cov1, cov2, mean1, mean2):
    #Fisher-model  inter-class / intra-class variance
    c1c2 = cov1 + cov2
    m1m2 = np.array(list(map(lambda x,y : x-y, mean1, mean2)))
    w = np.dot(np.linalg.pinv(c1c2), (m1m2))
    intraClass = np.dot(np.dot(w.T, c1c2), w)
    interClass = np.dot(w, m1m2)**2
    fisher = interClass/intraClass
    print("fisher: {}\tinter-class: {}\tintra-class: {}".format(fisher, interClass, intraClass))

"""
    This method saves models to files
    @modelName -> path2model/trained-{modelName}
"""
def saveModelTofile(modelName, kernel, model):
    tmp = "{}-".format(kernel) if not kernel == "" else ""
    with open("{}/trained-{}{}".format(path2model, tmp, modelName), 'wb') as fp:
        pickle.dump(model, fp)

"""
    This method loads models from files
    if there is no such model, it returns None

    @modelName -> path2model/trained-{modelName}
    @returns True|False (if it could NOT be loaded), pretrained model
"""
def loadModelFromFile(modelName, kernel):
    try:
        tmp = "{}-".format(kernel) if not kernel == "" else ""
        with open ("{}/trained-{}{}".format(path2model, tmp, modelName), 'rb') as fp:
            pretrainedModel = pickle.load(fp)
        return False, pretrainedModel
    except:
        return True, None

def initEverything():
    X, Y, X_val, Y_val = getTrainingData()
    print(X.shape,Y.shape)
    print(Y_val.shape)

    means, C_inv, class_probability = loadModel(X, Y, "LDA", newDataset=False, langevinDynamics=False)
    logreg = loadModel(X,Y, "LogReg", newDataSet=False)
    linearSvm = loadModel(X, Y, "SVM", kernel = 'linear', newDataSet=False)
    rbfSvm = loadModel(X, Y, "SVM", kernel = 'rbf', newDataSet=False)
    polySvm = loadModel(X, Y, "SVM", kernel = 'poly', newDataSet=False)
    sigSvm = loadModel(X, Y, "SVM", kernel = 'sigmoid', newDataSet=False)
    


    # print support vectors
    #print("Support- vectors: {}\n{}\n{}".format(linearSvm.support_vectors_[0],linearSvm.support_vectors_[1],linearSvm.support_vectors_[2]))
    accurate = 100

    logRegVal = 100
    lsvmVal = 100
    rbfsvmVal = 100
    polsvmVal = 100
    sigsvmVal = 100
    lda = 100

    # method for accuracy
    reward = lambda y,yhat : 0 if y == round(yhat) else -1/Y_val.shape[0]

    #logreg = np.array(logreg)
    for i in range(len(Y_val)):
        if i%1000 == 0:
            print(i)
        #yhat = sigmoid(np.dot(X_val[i],logreg))
        #logRegVal = reward(Y_val[i], yhat)
        tmp = np.dot(means[0], C_inv)
        tmp1 = np.dot(tmp, X_val[i].T)-0.5*np.dot(tmp, means[0].T)+np.log(class_probability[0])
        tmp2 = np.dot(tmp, X_val[i].T)-0.5*np.dot(tmp, means[1].T)+np.log(class_probability[1])
        yhat = 1 if tmp1 > tmp2 else -1
        lda = reward(Y_val[i], yhat)
        lsvmVal += reward(Y_val[i], linearSvm.predict([X_val[i]])[0])
        rbfsvmVal += reward(Y_val[i], rbfSvm.predict([X_val[i]])[0])
        polsvmVal += reward(Y_val[i], polySvm.predict([X_val[i]])[0])
        sigsvmVal += reward(Y_val[i], sigSvm.predict([X_val[i]])[0])
    print("accuracy:\n\t- logReg: {}\n\t- linearSVM: {}\n\t- rbfSVM: {}\n\t- polySVM: {}\n\t- sigSVM: {}\n\t- LDA: {}".format(logRegVal, lsvmVal, rbfsvmVal, polsvmVal, sigsvmVal, lda))

initEverything()