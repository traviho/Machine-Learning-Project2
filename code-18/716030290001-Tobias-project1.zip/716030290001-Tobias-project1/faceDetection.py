import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from skimage import data
import pickle

def draw_on_plane(img, x, y):
    img_ = np.copy(img)
    for y_ in range(img_.shape[0]):
        for x_ in range(img_.shape[1]):
            if ((x_ == x or x_ == x+96) and y_ >= y and y_ <= y+96) or ((y_ == y or y_ == y+96) and x_ >= x and x_ <= x+96 ):
                img_[y_][x_] = [255,0,0]
    return img_

pyramid = []
with open ('pyramid-hog', 'rb') as fp:	#'trainingData
	pyramid = pickle.load(fp)

imgs = []
with open ('pyramidImages', 'rb') as fp:	#'trainingData
	imgs = pickle.load(fp)

linSVM = None
with open("trained-models/trained-linear-SVM", 'rb') as fp:
    linSVM = pickle.load(fp)

polySVM = None
with open("trained-models/trained-poly-SVM", 'rb') as fp:
    polySVM = pickle.load(fp)

lin = []
poly = []
results = []
for i in pyramid:
    lin = linSVM.predict(i)
    poly = polySVM.predict(i)
    results.append(poly)



bb = []
for i in range(len(imgs)):
    tmp = []
    for y in range(int((imgs[i].shape[0]-96)/10)):
        for x in range(int((imgs[i].shape[1]-96)/10)):
            if results[i][y+x] == 1:
                tmp.append((x*10,y*10))
    bb.append(tmp)
print(bb)
if bb == []:
    for i in range(len(imgs)):
        fig, ax = plt.subplots()
        ax.imshow(imgs[i])
        plt.show()


images = []
for img in range(len(bb)):
    hue = imgs[img]
    for i in range(len(bb[img])):
        hue = draw_on_plane(hue,bb[img][i][0],bb[img][i][1])
        hue = np.array(hue)
        #print(hue.shape)
    fig, ax = plt.subplots()
    ax.imshow(hue)
    plt.show()
    hue = []
            
#filter svm sayys yes
#draw those x,y coordinates on the plane


