from __future__ import print_function
import time
import numpy as np
import pandas as pd
from sklearn import datasets
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
#matplotlib inline
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import seaborn as sns
import pickle

def loadData():
    tdh = "trainingData/trainingDataHog-folder-"
    
    p = ["1-to-4", "5-to-8", "9-to-10"]
    path = [tdh + i for i in p]
    X_train = []
    Y_train = []
    for i in range(1):
        with open(path[i], 'rb') as u:
            loadedData = pickle.load(u)
            if i == 0:      #pos and neg. samples are train data
                X_train += [i["x"] for i in loadedData]
                Y_train += [i["y"] for i in loadedData]
            else:    #pos are train data, neg are val data
                X_train += [i["x"] for i in loadedData if i["y"] == 1]
                Y_train += [i["y"] for i in loadedData if i["y"] == 1]
        print("loaded-folder: {}".format(i+1))

    #rgb2gray = lambda rgb: np.dot(rgb[...,:3], [0.2989, 0.5870, 0.1140])
    #imgLambda = lambda img: rgb2gray(np.array(img))
    #X_train = np.array(list(map(imgLambda, X_train)))
    return np.array(X_train), np.array(Y_train)



X,y = loadData()#mnist = datasets.load_digits()
#X = mnist.data / 255.0
#y = mnist.target
#X = np.reshape(X.shape[0], 9216)
#print(X.shape, y.shape)

#[out] (70000, 784) (70000,)

feat_cols = [ 'pixel'+str(i) for i in range(X.shape[1]) ]
df = pd.DataFrame(X,columns=feat_cols)
df['y'] = y
df['label'] = df['y'].apply(lambda i: str(i))
X, y = None, None
print('Size of the dataframe: {}'.format(df.shape))
#[out] Size of the dataframe: (70000, 785)


# For reproducability of the results
np.random.seed(42)
rndperm = np.random.permutation(df.shape[0])


pca = PCA(n_components=3)
pca_result = pca.fit_transform(df[feat_cols].values)
df['pca-one'] = pca_result[:,0]
df['pca-two'] = pca_result[:,1] 
df['pca-three'] = pca_result[:,2]
print('Explained variation per principal component: {}'.format(pca.explained_variance_ratio_))

N = 10000
df_subset = df.loc[rndperm[:N],:].copy()
data_subset = df_subset[feat_cols].values
pca = PCA(n_components=3)
pca_result = pca.fit_transform(data_subset)
df_subset['pca-one'] = pca_result[:,0]
df_subset['pca-two'] = pca_result[:,1] 
df_subset['pca-three'] = pca_result[:,2]
print('Explained variation per principal component: {}'.format(pca.explained_variance_ratio_))
#[out] Explained variation per principal component: [0.09730166 0.07135901 0.06183721]

time_start = time.time()
tsne = TSNE(n_components=2, verbose=1, perplexity=40, n_iter=300)
tsne_results = tsne.fit_transform(data_subset)
print('t-SNE done! Time elapsed: {} seconds'.format(time.time()-time_start))

df_subset['tsne-2d-one'] = tsne_results[:,0]
df_subset['tsne-2d-two'] = tsne_results[:,1]

"""
plt.figure(figsize=(16,10))
sns.scatterplot(
    x="tsne-2d-one", y="tsne-2d-two",
    hue="y",
    #palette=sns.color_palette("hls", 10),
    data=df_subset,
    legend="full",
    alpha=0.3
)
plt.show()

plt.figure(figsize=(16,7))
ax1 = plt.subplot(1, 2, 1)
sns.scatterplot(
    x="pca-one", y="pca-two",
    hue="y",
    #palette=sns.color_palette("hls", 10),
    data=df_subset,
    legend="full",
    alpha=0.3,
    ax=ax1
)
ax2 = plt.subplot(1, 2, 2)
sns.scatterplot(
    x="tsne-2d-one", y="tsne-2d-two",
    hue="y",
    #palette=sns.color_palette("hls", 10),
    data=df_subset,
    legend="full",
    alpha=0.3,
    ax=ax2
)
plt.show()"""

pca_50 = PCA(n_components=50)
pca_result_50 = pca_50.fit_transform(data_subset)
print('Cumulative explained variation for 50 principal components: {}'.format(np.sum(pca_50.explained_variance_ratio_)))


time_start = time.time()
tsne = TSNE(n_components=2, verbose=0, perplexity=40, n_iter=300)
tsne_pca_results = tsne.fit_transform(pca_result_50)
print('t-SNE done! Time elapsed: {} seconds'.format(time.time()-time_start))

df_subset['tsne-pca50-one'] = tsne_pca_results[:,0]
df_subset['tsne-pca50-two'] = tsne_pca_results[:,1]
plt.figure(figsize=(16,4))
ax1 = plt.subplot(1, 3, 1)
sns.scatterplot(
    x="pca-one", y="pca-two",
    hue="y",
    #palette=sns.color_palette("bright"),#("hls", 50),
    data=df_subset,
    legend="full",
    alpha=0.3,
    ax=ax1
)
ax2 = plt.subplot(1, 3, 2)
sns.scatterplot(
    x="tsne-2d-one", y="tsne-2d-two",
    hue="y",
    #palette=sns.color_palette("bright"),#("hls", 50),
    data=df_subset,
    legend="full",
    alpha=0.3,
    ax=ax2
)
ax3 = plt.subplot(1, 3, 3)
sns.scatterplot(
    x="tsne-pca50-one", y="tsne-pca50-two",
    hue="y",
    #palette=sns.color_palette("bright"),#("hls", 50),
    data=df_subset,
    legend="full",
    alpha=0.3,
    ax=ax3
)
plt.show()

